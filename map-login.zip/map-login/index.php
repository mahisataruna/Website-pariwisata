<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Portal MAP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="style.css">
    
</head>
<body>
    <br/>
    <br/>
    <center><h2>Selamat datang di portal anggota</h2></center>
    <center><h3>silahkan login dahulu</h3></center>
    <br/>

    <center><div class="login">
    <br/>
        <form action="login.php" method="post" onSubmit="return validasi()">
            <div>
                <label>Username :</label>
                <input type="text" name="username" id="username"/>
            </div>
            <div>
                <label>Password :</label>
                <input type="password" name="password" id="password"/>
            </div>
            <div>
                <input type="submit" value="Login" class="tombol">
            </div>
            <p>Jika lupa password harap hubungi admin !</p>
        </form>
        <form action="utama.html" method="post">
            <div>
                <input type="submit" value="Home" class="fa fa-home">
</div>
</form>
    </div></center>
</body>

<!-- script-->

<script type="text/javascript">
    function validasi(){
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;
        if (username != "" && password !="") {
            return true;

        }else{
            alert('Username dan Password harus di isi !');
            return false;
        }
    }
</script>    
</html>