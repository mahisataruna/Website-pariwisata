<?php


//mengaktifkan session
session_start();

//cek apakah user sudah login
if ($_SESSION['status'] !="login"){
    header("location:index2.php");
}

//menampilkan timeline anggota
echo "Hai, selamat datang". $_SESSION['username'];

?>
<br/>
<br/>
<a href="logout.php">Keluar</a>


