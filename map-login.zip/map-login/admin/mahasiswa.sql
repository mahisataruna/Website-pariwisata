<!DOCTYPE html>
<html dir="ltr" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><meta charset="utf-8"><meta name="referrer" content="no-referrer"><meta name="robots" content="noindex,nofollow"><meta http-equiv="X-UA-Compatible" content="IE=Edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="icon" href="http://localhost/phpmyadmin/favicon.ico" type="image/x-icon"><link rel="shortcut icon" href="http://localhost/phpmyadmin/favicon.ico" type="image/x-icon"><link rel="stylesheet" type="text/css" href="mahasiswa_files/jquery-ui.css"><link rel="stylesheet" type="text/css" href="mahasiswa_files/codemirror.css"><link rel="stylesheet" type="text/css" href="mahasiswa_files/show-hint.css"><link rel="stylesheet" type="text/css" href="mahasiswa_files/lint.css"><link rel="stylesheet" type="text/css" href="mahasiswa_files/phpmyadmin.css"><link rel="stylesheet" type="text/css" href="mahasiswa_files/printview.css" media="print" id="printcss"><title>localhost / 127.0.0.1 / mahasiswa | phpMyAdmin 4.8.4</title><script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery_006.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery-migrate.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/whitelist.php"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/sprintf.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/ajax.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/keyhandler.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery-ui.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/js.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery_004.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery_003.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery-ui-timepicker-addon.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery_002.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery_005.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/menu-resizer.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/cross_framing_protection.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/rte.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/tracekit.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/error_report.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/messages.php"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/config.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/doclinks.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/functions.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/navigation.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/indexes.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/common.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/page_settings.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/shortcuts_handler.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/jquery_007.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/tbl_change.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/gis_data_editor.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/multi_column_sort.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/makegrid.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/sql_002.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/codemirror.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/sql.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/runmode.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/show-hint.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/sql-hint.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/lint.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/sql-lint.js"></script>
<script data-cfasync="false" type="text/javascript" src="mahasiswa_files/console.js"></script>
<script data-cfasync="false" type="text/javascript">// <![CDATA[
PMA_commonParams.setAll({common_query:"",opendb_url:"db_structure.php",lang:"en",server:"1",table:"user",db:"mahasiswa",token:"P&af_7x$QTS8/}_Y",text_dir:"ltr",show_databases_navigation_as_tree:true,pma_text_default_tab:"Browse",pma_text_left_default_tab:"Structure",pma_text_left_default_tab2:false,LimitChars:"50",pftext:"P",confirm:true,LoginCookieValidity:"1440",session_gc_maxlifetime:"1440",logged_in:true,is_https:false,rootPath:"/phpmyadmin/",arg_separator:"&",PMA_VERSION:"4.8.4",auth_type:"config",user:"root"});
ConsoleEnterExecutes=false
AJAX.scriptHandler.add("vendor/jquery/jquery.min.js",0).add("vendor/jquery/jquery-migrate.js",0).add("whitelist.php",1).add("vendor/sprintf.js",1).add("ajax.js",0).add("keyhandler.js",1).add("vendor/jquery/jquery-ui.min.js",0).add("vendor/js.cookie.js",1).add("vendor/jquery/jquery.mousewheel.js",0).add("vendor/jquery/jquery.event.drag-2.2.js",0).add("vendor/jquery/jquery.validate.js",0).add("vendor/jquery/jquery-ui-timepicker-addon.js",0).add("vendor/jquery/jquery.ba-hashchange-1.3.js",0).add("vendor/jquery/jquery.debounce-1.0.5.js",0).add("menu-resizer.js",1).add("cross_framing_protection.js",0).add("rte.js",1).add("vendor/tracekit.js",1).add("error_report.js",1).add("messages.php",0).add("config.js",1).add("doclinks.js",1).add("functions.js",1).add("navigation.js",1).add("indexes.js",1).add("common.js",1).add("page_settings.js",1).add("shortcuts_handler.js",1).add("vendor/jquery/jquery.uitablefilter.js",0).add("tbl_change.js",1).add("gis_data_editor.js",1).add("multi_column_sort.js",1).add("makegrid.js",1).add("sql.js",1).add("vendor/codemirror/lib/codemirror.js",0).add("vendor/codemirror/mode/sql/sql.js",0).add("vendor/codemirror/addon/runmode/runmode.js",0).add("vendor/codemirror/addon/hint/show-hint.js",0).add("vendor/codemirror/addon/hint/sql-hint.js",0).add("vendor/codemirror/addon/lint/lint.js",0).add("codemirror/addon/lint/sql-lint.js",0).add("console.js",1);
$(function() {AJAX.fireOnload("whitelist.php");AJAX.fireOnload("vendor/sprintf.js");AJAX.fireOnload("keyhandler.js");AJAX.fireOnload("vendor/js.cookie.js");AJAX.fireOnload("menu-resizer.js");AJAX.fireOnload("rte.js");AJAX.fireOnload("vendor/tracekit.js");AJAX.fireOnload("error_report.js");AJAX.fireOnload("config.js");AJAX.fireOnload("doclinks.js");AJAX.fireOnload("functions.js");AJAX.fireOnload("navigation.js");AJAX.fireOnload("indexes.js");AJAX.fireOnload("common.js");AJAX.fireOnload("page_settings.js");AJAX.fireOnload("shortcuts_handler.js");AJAX.fireOnload("tbl_change.js");AJAX.fireOnload("gis_data_editor.js");AJAX.fireOnload("multi_column_sort.js");AJAX.fireOnload("makegrid.js");AJAX.fireOnload("sql.js");AJAX.fireOnload("console.js");});
// ]]></script><noscript><style>html{display:block}</style></noscript><script type="text/javascript" src="mahasiswa_files/db_structure.js"></script></head><body style="margin-left: 240px; margin-bottom: 18.1px; padding-top: 58.1px; cursor: inherit; -moz-user-select: inherit;"><div id="pma_navigation" style="width: 240px;"><div id="pma_navigation_resizer" style="left: 240px; width: 3px;"></div><div id="pma_navigation_collapser" style="left: 240px;" title="Hide panel">←</div><div id="pma_navigation_content"><div id="pma_navigation_header"><a class="hide navigation_url" href="http://localhost/phpmyadmin/navigation.php?ajax_request=1"></a>    <div id="pmalogo">
                    <a href="http://localhost/phpmyadmin/index.php">
                <img src="mahasiswa_files/logo_left.png" alt="phpMyAdmin" id="imgpmalogo">
                    </a>
            </div>
<!-- LINKS START --><div id="navipanellinks"><a href="http://localhost/phpmyadmin/index.php" title="Home"><img src="mahasiswa_files/dot.gif" title="Home" alt="Home" class="icon ic_b_home"></a><a href="http://localhost/phpmyadmin/logout.php" class="logout disableAjax" title="Empty session data"><img src="mahasiswa_files/dot.gif" title="Empty session data" alt="Empty session data" class="icon ic_s_loggoff"></a><a href="http://localhost/phpmyadmin/doc/html/index.html" target="documentation" title="phpMyAdmin documentation"><img src="mahasiswa_files/dot.gif" title="phpMyAdmin documentation" alt="phpMyAdmin documentation" class="icon ic_b_docs"></a><a href="http://localhost/phpmyadmin/url.php?url=https%3A%2F%2Fdev.mysql.com%2Fdoc%2Frefman%2F5.7%2Fen%2Findex.html" target="mysql_doc" title="Documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_sqlhelp"></a><a href="#" id="pma_navigation_settings_icon" title="Navigation panel settings"><img src="mahasiswa_files/dot.gif" title="Navigation panel settings" alt="Navigation panel settings" class="icon ic_s_cog"></a><a href="#" id="pma_navigation_reload" title="Reload navigation panel"><img src="mahasiswa_files/dot.gif" title="Reload navigation panel" alt="Reload navigation panel" class="icon ic_s_reload"></a></div><!-- LINKS ENDS --><img src="mahasiswa_files/dot.gif" title="Loading…" alt="Loading…" style="visibility: hidden; display:none" class="icon ic_ajax_clock_small throbber"></div><div id="pma_navigation_tree" class="list_container synced highlight" style="height: 598.9px;"><div class="pma_quick_warp"><div class="drop_list"><span title="Recent tables" class="drop_button">Recent</span><ul id="pma_recent_list"><li class="warp_link"><a href="http://localhost/phpmyadmin/tbl_recent_favorite.php?db=mahasiswa&amp;table=user">`mahasiswa`.`user`</a></li><li class="warp_link"><a href="http://localhost/phpmyadmin/tbl_recent_favorite.php?db=map&amp;table=user">`map`.`user`</a></li><li class="warp_link"><a href="http://localhost/phpmyadmin/tbl_recent_favorite.php?db=map&amp;table=User">`map`.`User`</a></li></ul></div><div class="drop_list"><span title="Favorite tables" class="drop_button">Favorites</span><ul id="pma_favorite_list"><li class="warp_link">There are no favorite tables.</li></ul></div><div class="clearfloat"></div></div><div class="clearfloat"></div><ul><!-- CONTROLS START --><li id="navigation_controls_outer"><div id="navigation_controls"><a href="#" id="pma_navigation_collapse" title="Collapse all"><img src="mahasiswa_files/dot.gif" title="Collapse all" alt="Collapse all" class="icon ic_s_collapseall"></a><a href="#" id="pma_navigation_sync" title="Unlink from main panel"><img src="mahasiswa_files/dot.gif" title="Unlink from main panel" alt="Unlink from main panel" class="icon ic_s_link"></a></div></li><!-- CONTROLS ENDS --></ul><div id="pma_navigation_tree_content" style="height: 552.9px;"><ul><li class="first new_database italics"><div class="block"><i class="first"></i></div><div class="block "><a href="http://localhost/phpmyadmin/server_databases.php?server=1"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_b_newdb"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/server_databases.php?server=1" title="">New</a><div class="clearfloat"></div></li><li class="database"><div class="block"><i></i><b></b><a class="expander" href="#"><span class="hide aPath">cm9vdA==.ZGJfd29yZHByZXNz</span><span class="hide vPath">cm9vdA==.ZGJfd29yZHByZXNz</span><span class="hide pos">0</span><img src="mahasiswa_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus"></a></div><div class="block "><a href="http://localhost/phpmyadmin/db_operations.php?server=1&amp;db=db_wordpress&amp;"><img src="mahasiswa_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/db_structure.php?server=1&amp;db=db_wordpress" title="Structure">db_wordpress</a><div class="clearfloat"></div></li><li class="database"><div class="block"><i></i><b></b><a class="expander" href="#"><span class="hide aPath">cm9vdA==.aW5mb3JtYXRpb25fc2NoZW1h</span><span class="hide vPath">cm9vdA==.aW5mb3JtYXRpb25fc2NoZW1h</span><span class="hide pos">0</span><img src="mahasiswa_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus"></a></div><div class="block "><a href="http://localhost/phpmyadmin/db_operations.php?server=1&amp;db=information_schema&amp;"><img src="mahasiswa_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/db_structure.php?server=1&amp;db=information_schema" title="Structure">information_schema</a><div class="clearfloat"></div></li><li class="database selected"><div class="block"><i></i><b></b><a class="expander loaded" href="#"><span class="hide aPath">cm9vdA==.bWFoYXNpc3dh</span><span class="hide vPath">cm9vdA==.bWFoYXNpc3dh</span><span class="hide pos">0</span><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_b_minus"></a></div><div class="block "><a href="http://localhost/phpmyadmin/db_operations.php?server=1&amp;db=mahasiswa&amp;"><img src="mahasiswa_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/db_structure.php?server=1&amp;db=mahasiswa" title="Structure">mahasiswa</a><div class="clearfloat"></div><div class="list_container"><ul><span class="hide pos2_name">tables</span><span class="hide pos2_value">0</span><li class="new_table italics new_table italics"><div class="block"><i></i><span class="hide pos2_name">tables</span><span class="hide pos2_value">0</span></div><div class="block "><a href="http://localhost/phpmyadmin/tbl_create.php?server=1&amp;db=mahasiswa"><img src="mahasiswa_files/dot.gif" title="New" alt="New" class="icon ic_b_table_add"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/tbl_create.php?server=1&amp;db=mahasiswa" title="">New</a><div class="clearfloat"></div></li><li class="table last table"><div class="block"><i></i><a class="expander" href="#"><span class="hide aPath">cm9vdA==.bWFoYXNpc3dh.dGFibGVz.dXNlcg==</span><span class="hide vPath">cm9vdA==.bWFoYXNpc3dh.VGFibGVz.dXNlcg==</span><span class="hide pos">0</span><span class="hide pos2_name">tables</span><span class="hide pos2_value">0</span><img src="mahasiswa_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus"></a></div><div class="block "><a href="http://localhost/phpmyadmin/tbl_structure.php?server=1&amp;db=mahasiswa&amp;table=user"><img src="mahasiswa_files/dot.gif" title="Structure" alt="Structure" class="icon ic_b_props"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/sql.php?server=1&amp;db=mahasiswa&amp;table=user&amp;pos=0" title="Browse">user</a><span class="navItemControls"><a href="http://localhost/phpmyadmin/navigation.php" data-post="hideNavItem=1&amp;itemType=table&amp;itemName=user&amp;dbName=mahasiswa" class="hideNavItem ajax"><img src="mahasiswa_files/dot.gif" title="Hide" alt="Hide" class="icon ic_hide"></a></span><div class="clearfloat"></div></li></ul></div></li><li class="database"><div class="block"><i></i><b></b><a class="expander" href="#"><span class="hide aPath">cm9vdA==.bWFw</span><span class="hide vPath">cm9vdA==.bWFw</span><span class="hide pos">0</span><img src="mahasiswa_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus"></a></div><div class="block "><a href="http://localhost/phpmyadmin/db_operations.php?server=1&amp;db=map&amp;"><img src="mahasiswa_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/db_structure.php?server=1&amp;db=map" title="Structure">map</a><div class="clearfloat"></div></li><li class="database"><div class="block"><i></i><b></b><a class="expander" href="#"><span class="hide aPath">cm9vdA==.bXlzcWw=</span><span class="hide vPath">cm9vdA==.bXlzcWw=</span><span class="hide pos">0</span><img src="mahasiswa_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus"></a></div><div class="block "><a href="http://localhost/phpmyadmin/db_operations.php?server=1&amp;db=mysql&amp;"><img src="mahasiswa_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/db_structure.php?server=1&amp;db=mysql" title="Structure">mysql</a><div class="clearfloat"></div></li><li class="database"><div class="block"><i></i><b></b><a class="expander" href="#"><span class="hide aPath">cm9vdA==.cGVyZm9ybWFuY2Vfc2NoZW1h</span><span class="hide vPath">cm9vdA==.cGVyZm9ybWFuY2Vfc2NoZW1h</span><span class="hide pos">0</span><img src="mahasiswa_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus"></a></div><div class="block "><a href="http://localhost/phpmyadmin/db_operations.php?server=1&amp;db=performance_schema&amp;"><img src="mahasiswa_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/db_structure.php?server=1&amp;db=performance_schema" title="Structure">performance_schema</a><div class="clearfloat"></div></li><li class="database"><div class="block"><i></i><b></b><a class="expander" href="#"><span class="hide aPath">cm9vdA==.cGhwbXlhZG1pbg==</span><span class="hide vPath">cm9vdA==.cGhwbXlhZG1pbg==</span><span class="hide pos">0</span><img src="mahasiswa_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus"></a></div><div class="block "><a href="http://localhost/phpmyadmin/db_operations.php?server=1&amp;db=phpmyadmin&amp;"><img src="mahasiswa_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/db_structure.php?server=1&amp;db=phpmyadmin" title="Structure">phpmyadmin</a><div class="clearfloat"></div></li><li class="last database"><div class="block"><i></i><a class="expander" href="#"><span class="hide aPath">cm9vdA==.dGVzdA==</span><span class="hide vPath">cm9vdA==.dGVzdA==</span><span class="hide pos">0</span><img src="mahasiswa_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus"></a></div><div class="block "><a href="http://localhost/phpmyadmin/db_operations.php?server=1&amp;db=test&amp;"><img src="mahasiswa_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a></div><a class="hover_show_full" href="http://localhost/phpmyadmin/db_structure.php?server=1&amp;db=test" title="Structure">test</a><div class="clearfloat"></div></li></ul></div></div><div id="pma_navi_settings_container"></div></div><div class="pma_drop_handler">Drop files here</div><div class="pma_sql_import_status"><h2>SQL upload ( <span class="pma_import_count">0</span> ) <span class="close">x</span><span class="minimize">-</span></h2><div></div></div></div><div id="floating_menubar" style="margin-left: 243px; left: 0px; position: fixed; top: 0px; width: 100%; z-index: 99;"><div id="serverinfo"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_host item"><a href="http://localhost/phpmyadmin/index.php" class="item">Server: 127.0.0.1</a><span class="separator item">&nbsp;»</span><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_db item"><a href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa" class="item">Database: mahasiswa</a><div class="clearfloat"></div></div><div id="topmenucontainer" class="menucontainer"><i class="scrollindicator scrollindicator--left"><img alt="" title="" src="mahasiswa_files/dot.gif" class="icon ic_b_left"></i><div class="navigationbar" style="width: auto; overflow: visible;"><ul id="topmenu" class="resizable-menu"><li class="active">

            <a href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa" class="tabactive">
            <img src="mahasiswa_files/dot.gif" title="Structure" alt="Structure" class="icon ic_b_props">&nbsp;Structure
            </a>
        </li>
<li>

            <a href="http://localhost/phpmyadmin/db_sql.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="SQL" alt="SQL" class="icon ic_b_sql">&nbsp;SQL
            </a>
        </li>
<li>

            <a href="http://localhost/phpmyadmin/db_search.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Search" alt="Search" class="icon ic_b_search">&nbsp;Search
            </a>
        </li>
<li>

            <a href="http://localhost/phpmyadmin/db_multi_table_query.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Query" alt="Query" class="icon ic_s_db">&nbsp;Query
            </a>
        </li>
<li>

            <a href="http://localhost/phpmyadmin/db_export.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Export" alt="Export" class="icon ic_b_export">&nbsp;Export
            </a>
        </li>
<li>

            <a href="http://localhost/phpmyadmin/db_import.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Import" alt="Import" class="icon ic_b_import">&nbsp;Import
            </a>
        </li>
<li>

            <a href="http://localhost/phpmyadmin/db_operations.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Operations" alt="Operations" class="icon ic_b_tblops">&nbsp;Operations
            </a>
        </li>
<li>

            <a href="http://localhost/phpmyadmin/server_privileges.php?db=mahasiswa&amp;checkprivsdb=mahasiswa&amp;viewing_mode=db" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Privileges" alt="Privileges" class="icon ic_s_rights">&nbsp;Privileges
            </a>
        </li>
<li>

            <a href="http://localhost/phpmyadmin/db_routines.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Routines" alt="Routines" class="icon ic_b_routines">&nbsp;Routines
            </a>
        </li>
<li>

            <a href="http://localhost/phpmyadmin/db_events.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Events" alt="Events" class="icon ic_b_events">&nbsp;Events
            </a>
        </li>




<li class="submenu shown" style=""><a href="#" class="tab nowrap"><img alt="" title="" src="mahasiswa_files/dot.gif" class="icon ic_b_more">More</a><ul class="notonly"><li>

            <a href="http://localhost/phpmyadmin/db_triggers.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Triggers" alt="Triggers" class="icon ic_b_triggers">&nbsp;Triggers
            </a>
        </li><li>

            <a href="http://localhost/phpmyadmin/db_tracking.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Tracking" alt="Tracking" class="icon ic_eye">&nbsp;Tracking
            </a>
        </li><li>

            <a href="http://localhost/phpmyadmin/db_designer.php?db=mahasiswa" id="designer_tab" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Designer" alt="Designer" class="icon ic_b_relations">&nbsp;Designer
            </a>
        </li><li>

            <a href="http://localhost/phpmyadmin/db_central_columns.php?db=mahasiswa" class="tab">
            <img src="mahasiswa_files/dot.gif" title="Central columns" alt="Central columns" class="icon ic_centralColumns">&nbsp;Central columns
            </a>
        </li></ul></li><div class="clearfloat"></div></ul></div>
<i class="scrollindicator scrollindicator--right"><img alt="" title="" src="mahasiswa_files/dot.gif" class="icon ic_b_right"></i></div>
</div>
<span id="page_nav_icons"><span id="lock_page_icon"></span><span id="page_settings_icon" style="display: inline;"><img src="mahasiswa_files/dot.gif" title="Page-related settings" alt="Page-related settings" class="icon ic_s_cog"></span><a id="goto_pagetop" href="#"><img src="mahasiswa_files/dot.gif" title="Click on the bar to scroll to top of page" alt="Click on the bar to scroll to top of page" class="icon ic_s_top"></a></span><div id="pma_console_container">
    <div id="pma_console" style="margin-left: 243px;">
                <div class="toolbar collapsed">
                    <div class="switch_button console_switch">
            <img src="mahasiswa_files/dot.gif" title="SQL Query Console" alt="SQL Query Console" class="icon ic_console">
            <span>Console</span>
        </div>
                            <div class="button clear">
            
            <span>Clear</span>
        </div>
                            <div class="button history">
            
            <span>History</span>
        </div>
                            <div class="button options">
            
            <span>Options</span>
        </div>
                            <div class="button bookmarks">
            
            <span>Bookmarks</span>
        </div>
                            <div class="button debug hide">
            
            <span>Debug SQL</span>
        </div>
            </div>
                <div class="content" style="height: 92px; margin-bottom: -98.25px; display: none;">
            <div class="console_message_container">
                <div class="message welcome binded">
                    <span id="instructions-0">
                        Press Ctrl+Enter to execute query                    </span>
                    <span class="hide" id="instructions-1">
                        Press Enter to execute query                    </span>
                </div>
                                                            <div class="message history collapsed hide select binded" targetdb="map" targettable="user">
                            <div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span>map</span>
                    </span>
                            <span class="text query_time">
            Queried time
                            : <span>During current session</span>
                    </span>
            </div>
                            <span class="query highlighted"><span class="cm-keyword">SELECT</span> * <span class="cm-keyword">FROM</span> `user`</span>
                        </div>
                                            <div class="message history collapsed hide binded" targetdb="map" targettable="user">
                            <div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span>map</span>
                    </span>
                            <span class="text query_time">
            Queried time
                            : <span>During current session</span>
                    </span>
            </div>
                            <span class="query highlighted"><span class="cm-keyword">INSERT</span> <span class="cm-keyword">INTO</span> `user` (`noregis`, `username`, `email`, `password`, `nama`, `photo`) <span class="cm-keyword">VALUES</span> (<span class="cm-string">'10116'</span>, <span class="cm-string">'map10116'</span>, <span class="cm-string">'ari@gmail.com'</span>, <span class="cm-string">'123456'</span>, <span class="cm-string">'Depany Ariwiski'</span>, <span class="cm-string">'default.svg'</span>);</span>
                        </div>
                                            <div class="message history collapsed hide select binded" targetdb="map" targettable="user">
                            <div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span>map</span>
                    </span>
                            <span class="text query_time">
            Queried time
                            : <span>During current session</span>
                    </span>
            </div>
                            <span class="query highlighted"><span class="cm-keyword">SELECT</span> * <span class="cm-keyword">FROM</span> `user`</span>
                        </div>
                                            <div class="message history collapsed hide binded" targetdb="mahasiswa" targettable="user">
                            <div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span>mahasiswa</span>
                    </span>
                            <span class="text query_time">
            Queried time
                            : <span>During current session</span>
                    </span>
            </div>
                            <span class="query highlighted"><span class="cm-keyword">CREATE</span> <span class="cm-keyword">TABLE</span> `mahasiswa`.`user` ( `noregis` <span class="cm-builtin">INT</span> <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span> AUTO_INCREMENT ,  `nama` <span class="cm-builtin">VARCHAR</span>(<span class="cm-number">255</span>) <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span> ,  `username` <span class="cm-builtin">VARCHAR</span>(<span class="cm-number">255</span>) <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span> ,  `password` <span class="cm-builtin">VARCHAR</span>(<span class="cm-number">255</span>) <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span> ,  `email` <span class="cm-builtin">VARCHAR</span>(<span class="cm-number">255</span>) <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span> ,  `hp` <span class="cm-builtin">VARCHAR</span>(<span class="cm-number">255</span>) <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span> ,  `alamat` <span class="cm-builtin">VARCHAR</span>(<span class="cm-number">255</span>) <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span> ,    PRIMARY KEY  (`noregis`)) ENGINE = InnoDB;</span>
                        </div>
                                            <div class="message history collapsed hide binded" targetdb="mahasiswa" targettable="user">
                            <div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span>mahasiswa</span>
                    </span>
                            <span class="text query_time">
            Queried time
                            : <span>During current session</span>
                    </span>
            </div>
                            <span class="query highlighted"><span class="cm-keyword">INSERT</span> <span class="cm-keyword">INTO</span> `user` (`noregis`,`nama`,`username`,`password`,`email`,`hp`,`alamat`) <span class="cm-keyword">VALUES</span>
(<span class="cm-number">10116</span>,<span class="cm-string">'Depany Ariwiski'</span>,<span class="cm-string">'map10116'</span>,<span class="cm-string">'12345678'</span>,<span class="cm-string">'ari@gmail.com'</span>,<span class="cm-string">'081378240491'</span>,<span class="cm-string">'Lubuk Buaya'</span>)</span>
                        </div>
                                            <div class="message history collapsed hide select binded" targetdb="mahasiswa" targettable="user">
                            <div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span>mahasiswa</span>
                    </span>
                            <span class="text query_time">
            Queried time
                            : <span>During current session</span>
                    </span>
            </div>
                            <span class="query highlighted"><span class="cm-keyword">SELECT</span> * <span class="cm-keyword">FROM</span> `user`</span>
                        </div>
                                            <div class="message history collapsed hide select binded" targetdb="mahasiswa" targettable="user">
                            <div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span>mahasiswa</span>
                    </span>
                            <span class="text query_time">
            Queried time
                            : <span>During current session</span>
                    </span>
            </div>
                            <span class="query highlighted"><span class="cm-keyword">SELECT</span> * <span class="cm-keyword">FROM</span> `user`</span>
                        </div>
                                                <div class="message collapsed binded select successed" msgid="787816411078" targetdb="mahasiswa" targettable="user"><div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                    </span>
                            <span class="text query_time">
            Queried time
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">SELECT</span> * <span class="cm-keyword">FROM</span> `user`</div></div></div><!-- console_message_container -->
            <div class="query_input">
                <span class="console_query_input"><div class="CodeMirror cm-s-pma CodeMirror-wrap"><div style="overflow: hidden; position: relative; width: 3px; height: 0px; top: 0px; left: 16px;"><textarea style="position: absolute; bottom: -1em; padding: 0px; width: 1px; height: 1em; outline: currentcolor none medium;" autocorrect="off" autocapitalize="off" spellcheck="false" tabindex="0" wrap="off"></textarea></div><div class="CodeMirror-vscrollbar" cm-not-content="true"><div style="min-width: 1px; height: 0px;"></div></div><div class="CodeMirror-hscrollbar" cm-not-content="true"><div style="height: 100%; min-height: 1px; width: 0px;"></div></div><div class="CodeMirror-scrollbar-filler" cm-not-content="true"></div><div class="CodeMirror-gutter-filler" cm-not-content="true"></div><div class="CodeMirror-scroll" tabindex="-1" draggable="true"><div class="CodeMirror-sizer" style="margin-left: 16px; margin-bottom: -17px; border-right-width: 13px; min-height: 15px; padding-right: 0px; padding-bottom: 0px;"><div style="position: relative; top: 0px;"><div class="CodeMirror-lines" role="presentation"><div style="position: relative; outline: currentcolor none medium;" role="presentation"><div class="CodeMirror-measure"><span><span>​</span>x</span></div><div class="CodeMirror-measure"></div><div style="position: relative; z-index: 1;"></div><div class="CodeMirror-cursors"><div class="CodeMirror-cursor" style="left: 0px; top: 0px; height: 15px;">&nbsp;</div></div><div class="CodeMirror-code" role="presentation"><pre class=" CodeMirror-line " role="presentation"><span role="presentation"><span cm-text="">​</span></span></pre></div></div></div></div></div><div style="position: absolute; height: 13px; width: 1px; border-bottom: 0px solid transparent; top: 15px;"></div><div class="CodeMirror-gutters" style="height: 28px;"><div class="CodeMirror-gutter CodeMirror-lint-markers"></div></div></div></div></span>
            </div>
        </div><!-- message end -->
                <div class="mid_layer"></div>
                <div class="card ungrouped" id="debug_console">
            <div class="toolbar ">
                    <div class="button order order_asc active">
            
            <span>ascending</span>
        </div>
                            <div class="button order order_desc">
            
            <span>descending</span>
        </div>
                            <div class="text">
            
            <span>Order:</span>
        </div>
                            <div class="switch_button">
            
            <span>Debug SQL</span>
        </div>
                            <div class="button order_by sort_count">
            
            <span>Count</span>
        </div>
                            <div class="button order_by sort_exec active">
            
            <span>Execution order</span>
        </div>
                            <div class="button order_by sort_time">
            
            <span>Time taken</span>
        </div>
                            <div class="text">
            
            <span>Order by:</span>
        </div>
                            <div class="button group_queries">
            
            <span>Group queries</span>
        </div>
                            <div class="button ungroup_queries">
            
            <span>Ungroup queries</span>
        </div>
            </div>
            <div class="content debug" style="height: 92px;">
                <div class="message welcome binded">Some error occurred while getting SQL debug info.</div>
                <div class="debugLog"></div>
            </div> <!-- Content -->
            <div class="templates">
                <div class="debug_query action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action dbg_show_trace">
            Show trace
                    </span>
                            <span class="action dbg_hide_trace">
            Hide trace
                    </span>
                            <span class="text count hide">
            Count
                    </span>
                            <span class="text time">
            Time taken
                    </span>
            </div>
            </div> <!-- Template -->
        </div> <!-- Debug SQL card -->
                    <div class="card" id="pma_bookmarks">
                <div class="toolbar ">
                    <div class="switch_button">
            
            <span>Bookmarks</span>
        </div>
                            <div class="button refresh">
            
            <span>Refresh</span>
        </div>
                            <div class="button add">
            
            <span>Add</span>
        </div>
            </div>
                <div class="content bookmark" style="height: 92px;">
                    <div class="message welcome binded">
    <span>No bookmarks</span>
</div>

                </div>
                <div class="mid_layer"></div>
                <div class="card add">
                    <div class="toolbar ">
                    <div class="switch_button">
            
            <span>Add bookmark</span>
        </div>
            </div>
                    <div class="content add_bookmark" style="height: 92px;">
                        <div class="options">
                            <label>
                                Label: <input type="text" name="label">
                            </label>
                            <label>
                                Target database: <input type="text" name="targetdb">
                            </label>
                            <label>
                                <input type="checkbox" name="shared">Share this bookmark                            </label>
                            <button type="submit" name="submit">OK</button>
                        </div> <!-- options -->
                        <div class="query_input">
                            <span class="bookmark_add_input"><div class="CodeMirror cm-s-pma CodeMirror-wrap"><div style="overflow: hidden; position: relative; width: 3px; height: 0px; top: 0px; left: 16px;"><textarea style="position: absolute; bottom: -1em; padding: 0px; width: 1px; height: 1em; outline: currentcolor none medium;" autocorrect="off" autocapitalize="off" spellcheck="false" tabindex="0" wrap="off"></textarea></div><div class="CodeMirror-vscrollbar" cm-not-content="true"><div style="min-width: 1px; height: 0px;"></div></div><div class="CodeMirror-hscrollbar" cm-not-content="true"><div style="height: 100%; min-height: 1px; width: 0px;"></div></div><div class="CodeMirror-scrollbar-filler" cm-not-content="true"></div><div class="CodeMirror-gutter-filler" cm-not-content="true"></div><div class="CodeMirror-scroll" tabindex="-1" draggable="true"><div class="CodeMirror-sizer" style="margin-left: 16px; margin-bottom: -17px; border-right-width: 13px; min-height: 15px; padding-right: 0px; padding-bottom: 0px;"><div style="position: relative; top: 0px;"><div class="CodeMirror-lines" role="presentation"><div style="position: relative; outline: currentcolor none medium;" role="presentation"><div class="CodeMirror-measure"><pre><span>xxxxxxxxxx</span></pre></div><div class="CodeMirror-measure"></div><div style="position: relative; z-index: 1;"></div><div class="CodeMirror-cursors"><div class="CodeMirror-cursor" style="left: 0px; top: 0px; height: 15px;">&nbsp;</div></div><div class="CodeMirror-code" role="presentation"><pre class=" CodeMirror-line " role="presentation"><span role="presentation"><span cm-text="">​</span></span></pre></div></div></div></div></div><div style="position: absolute; height: 13px; width: 1px; border-bottom: 0px solid transparent; top: 15px;"></div><div class="CodeMirror-gutters" style="height: 28px;"><div class="CodeMirror-gutter CodeMirror-lint-markers"></div></div></div></div></span>
                        </div>
                    </div>
                </div> <!-- Add bookmark card -->
            </div> <!-- Bookmarks card -->
                        <div class="card" id="pma_console_options">
            <div class="toolbar ">
                    <div class="switch_button">
            
            <span>Options</span>
        </div>
                            <div class="button default">
            
            <span>Set default</span>
        </div>
            </div>
            <div class="content" style="height: 92px;">
                <label>
                    <input type="checkbox" name="always_expand">Always expand query messages                </label>
                <br>
                <label>
                    <input type="checkbox" name="start_history">Show query history at start                </label>
                <br>
                <label>
                    <input type="checkbox" name="current_query" checked="checked">Show current browsing query                </label>
                <br>
                <label>
                    <input type="checkbox" name="enter_executes">
                        Execute queries on Enter and insert new line 
with Shift + Enter. To make this permanent, view settings.              
  </label>
                <br>
                <label>
                    <input type="checkbox" name="dark_theme">Switch to dark theme                </label>
                <br>
            </div>
        </div> <!-- Options card -->
        <div class="templates">
                        <div class="query_actions">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                    </span>
                            <span class="text query_time">
            Queried time
                    </span>
            </div>
        </div>
    </div> <!-- #console end -->
</div> <!-- #console_container end -->
<div id="page_content"><div id="page_settings_modal"><div class="page_settings"><form method="post" action="db_structure.php?db=mahasiswa&amp;table=&amp;server=1&amp;target=" class="config-form disableAjax"><input type="hidden" name="tab_hash" value=""><input type="hidden" name="check_page_refresh" id="check_page_refresh" value="1">
<input type="hidden" name="token" value="P&amp;af_7x$QTS8/}_Y">
<input type="hidden" name="submit_save" value="DbStructure"><input type="hidden" name="token" value="P&amp;af_7x$QTS8/}_Y"><ul class="tabs responsivetable">

                                    <li class="active">

            <a href="#DbStructure">
            Database structure
            </a>
        </li>
            </ul>
<br><div class="tabs_contents"><fieldset class="optbox" id="DbStructure" style="">
<legend>Database structure</legend>
    <p>Choose which details to show in the database structure (list of tables).</p>
<table width="100%" cellspacing="0">
<tbody><tr><th><label for="ShowDbStructureCharset">Show table charset</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureCharset" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Show or hide a column displaying the charset for all tables.</small></th><td><span class="checkbox"><input type="checkbox" name="ShowDbStructureCharset" id="ShowDbStructureCharset"></span><a class="restore-default hide" href="#ShowDbStructureCharset" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="ShowDbStructureComment">Show table comments</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureComment" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Show or hide a column displaying the comments for all tables.</small></th><td><span class="checkbox"><input type="checkbox" name="ShowDbStructureComment" id="ShowDbStructureComment"></span><a class="restore-default hide" href="#ShowDbStructureComment" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="ShowDbStructureCreation">Show creation timestamp</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureCreation" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Show or hide a column displaying the Creation timestamp for all tables.</small></th><td><span class="checkbox"><input type="checkbox" name="ShowDbStructureCreation" id="ShowDbStructureCreation"></span><a class="restore-default hide" href="#ShowDbStructureCreation" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="ShowDbStructureLastUpdate">Show last update timestamp</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureLastUpdate" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Show or hide a column displaying the Last update timestamp for all tables.</small></th><td><span class="checkbox"><input type="checkbox" name="ShowDbStructureLastUpdate" id="ShowDbStructureLastUpdate"></span><a class="restore-default hide" href="#ShowDbStructureLastUpdate" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="ShowDbStructureLastCheck">Show last check timestamp</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureLastCheck" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Show or hide a column displaying the Last check timestamp for all tables.</small></th><td><span class="checkbox"><input type="checkbox" name="ShowDbStructureLastCheck" id="ShowDbStructureLastCheck"></span><a class="restore-default hide" href="#ShowDbStructureLastCheck" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr></tbody></table>
</fieldset>
</div>
</form>
<script type="text/javascript">
if (typeof configInlineParams === "undefined" || !Array.isArray(configInlineParams)) configInlineParams = [];
configInlineParams.push(function() {
$.extend(PMA_messages, {
	'error_nan_p': 'Not a positive number!',
	'error_nan_nneg': 'Not a non-negative number!',
	'error_incorrect_port': 'Not a valid port number!',
	'error_invalid_value': 'Incorrect value!',
	'error_value_lte': 'Value must be equal or lower than %s!'});
$.extend(defaultValues, {
	'ShowDbStructureCharset': false,
	'ShowDbStructureComment': false,
	'ShowDbStructureCreation': false,
	'ShowDbStructureLastUpdate': false,
	'ShowDbStructureLastCheck': false});
});
if (typeof configScriptLoaded !== "undefined" && configInlineParams) loadInlineConfig();
</script>
</div></div><div id="tableslistcontainer"><fieldset id="tableFilter">
    <legend>Filters</legend>
    <div class="formelement">
        <label for="filterText">Containing the word:</label>
        <input name="filterText" type="text" id="filterText">
    </div>
</fieldset>
<form method="post" action="db_structure.php" name="tablesForm" id="tablesForm">
<input type="hidden" name="db" value="mahasiswa"><input type="hidden" name="token" value="P&amp;af_7x$QTS8/}_Y">
<div class="responsivetable">
<table id="structureTable" class="data">
    <thead>
        <tr>
            <th class="print_ignore"></th>
            <th><a href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa&amp;pos=0&amp;sort=table&amp;sort_order=DESC" title="Sort" onmouseover="$('.sort_arrow').toggle();" onmouseout="$('.sort_arrow').toggle();">Table <img src="mahasiswa_files/dot.gif" title="" alt="Ascending" class="icon ic_s_asc sort_arrow" style=""> <img src="mahasiswa_files/dot.gif" title="" alt="Descending" class="icon ic_s_desc sort_arrow hide" style="display: none;"></a></th>
            
                                                                                            <th colspan="7" class="print_ignore">
                Action            </th>
                        <th>
                <a href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa&amp;pos=0&amp;sort=records&amp;sort_order=DESC" title="Sort">Rows</a>
                <span class="pma_hint"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_b_help"><span class="hide">May be approximate. Click on the number to get the exact count. See <a href="http://localhost/phpmyadmin/doc/html/faq.html#faq3-11" target="documentation">FAQ 3.11</a>.</span></span>
            </th>
                            <th><a href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa&amp;pos=0&amp;sort=type&amp;sort_order=ASC" title="Sort">Type</a></th>
                <th><a href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa&amp;pos=0&amp;sort=collation&amp;sort_order=ASC" title="Sort">Collation</a></th>
            
                                            <th><a href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa&amp;pos=0&amp;sort=size&amp;sort_order=DESC" title="Sort">Size</a></th>
                                <th><a href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa&amp;pos=0&amp;sort=overhead&amp;sort_order=DESC" title="Sort">Overhead</a></th>
            
            
            
            
            
                    </tr>
    </thead>
    <tbody>
<tr id="row_tbl_1" data-filter-row="USER">
    <td class="center print_ignore">
        <input type="checkbox" name="selected_tbl[]" class="checkall" value="user" id="checkbox_tbl_1">
    </td>
    <th>
        <a href="http://localhost/phpmyadmin/sql.php?db=mahasiswa&amp;table=user&amp;pos=0" title="">
    user
</a>

        
    </th>
    
                <td class="center print_ignore">
                                    <a id="ee11cbb19052e40b07aac0ca060c23ee_favorite_anchor" class="ajax favorite_table_anchor" href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa&amp;ajax_request=1&amp;favorite_table=user&amp;add_favorite=1" title="Add to Favorites" data-favtargets="c765fb27cdd2d26e6ba7be47d4154f70">
    <span class="nowrap"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_b_no_favorite">&nbsp;</span>
</a>
        </td>
    
    <td class="center print_ignore">
        <a href="http://localhost/phpmyadmin/sql.php?db=mahasiswa&amp;table=user&amp;pos=0">
    <span class="nowrap"><img src="mahasiswa_files/dot.gif" title="Browse" alt="Browse" class="icon ic_b_browse">&nbsp;Browse</span>
</a>

    </td>
    <td class="center print_ignore">
        <a href="http://localhost/phpmyadmin/tbl_structure.php?db=mahasiswa&amp;table=user">
            <span class="nowrap"><img src="mahasiswa_files/dot.gif" title="Structure" alt="Structure" class="icon ic_b_props">&nbsp;Structure</span>
        </a>
    </td>
    <td class="center print_ignore">
        <a href="http://localhost/phpmyadmin/tbl_select.php?db=mahasiswa&amp;table=user">
    <span class="nowrap"><img src="mahasiswa_files/dot.gif" title="Search" alt="Search" class="icon ic_b_select">&nbsp;Search</span>
</a>

    </td>

            <td class="insert_table center print_ignore">
            <a href="http://localhost/phpmyadmin/tbl_change.php?db=mahasiswa&amp;table=user"><span class="nowrap"><img src="mahasiswa_files/dot.gif" title="Insert" alt="Insert" class="icon ic_b_insrow">&nbsp;Insert</span></a>
        </td>
        <td class="center print_ignore"><a class="truncate_table_anchor ajax" href="http://localhost/phpmyadmin/sql.php" data-post="?db=mahasiswa&amp;table=user&amp;sql_query=TRUNCATE+%60user%60&amp;message_to_show=Table+user+has+been+emptied.">
    <span class="nowrap"><img src="mahasiswa_files/dot.gif" title="Empty" alt="Empty" class="icon ic_b_empty">&nbsp;Empty</span>
</a>
</td>
        <td class="center print_ignore">
            <a class="ajax drop_table_anchor" href="http://localhost/phpmyadmin/sql.php" data-post="?db=mahasiswa&amp;table=user&amp;reload=1&amp;purge=1&amp;sql_query=DROP%20TABLE%20%60user%60&amp;message_to_show=Table%20user%20has%20been%20dropped.">
                <span class="nowrap"><img src="mahasiswa_files/dot.gif" title="Drop" alt="Drop" class="icon ic_b_drop">&nbsp;Drop</span>
            </a>
        </td>
    
                    
                <td class="value tbl_rows" data-table="user">
                            1
                        
        </td>

                    <td class="nowrap">
                                    InnoDB
                            </td>
                            <td class="nowrap">
                    <dfn title="Swedish, case-insensitive">latin1_swedish_ci</dfn>
                </td>
                    
                    <td class="value tbl_size">
                <a href="http://localhost/phpmyadmin/tbl_structure.php?db=mahasiswa&amp;table=user#showusage">
                    <span>16</span>
                    <span class="unit">KiB</span>
                </a>
            </td>
            <td class="value tbl_overhead">
                -
            </td>
        
                            
        
        
        
        
    </tr>
</tbody><tbody id="tbl_summary_row">
<tr>
    <th class="print_ignore"></th>
    <th class="tbl_num nowrap">
                1 table
    </th>
                <th colspan="7" class="print_ignore">Sum</th>
                                                <th class="value tbl_rows">1</th>
                                    <th class="center">
            <dfn title="InnoDB is the default storage engine on this MySQL server.">
                InnoDB
            </dfn>
        </th>
        <th>
                            <dfn title="Swedish, case-insensitive (Default)">
                    latin1_swedish_ci
                </dfn>
                    </th>
    
                                    <th class="value tbl_size">16 KiB</th>

                                <th class="value tbl_overhead">0 B</th>
    
                    </tr>
</tbody>
</table><div class="clearfloat print_ignore">
    <img class="selectallarrow" src="mahasiswa_files/arrow_ltr.png" alt="With selected:" width="38" height="22">
    <input type="checkbox" id="tablesForm_checkall" class="checkall_box" title="Check all">
    <label for="tablesForm_checkall">Check all</label>
        <select name="submit_mult" style="margin: 0 3em 0 3em;">
        <option value="With selected:" selected="selected">With selected:</option>
        <option value="copy_tbl">Copy table</option>
        <option value="show_create">Show create</option>
        <option value="export">Export</option>
                    <optgroup label="Delete data or table">
                <option value="empty_tbl">Empty</option>
                <option value="drop_tbl">Drop</option>
            </optgroup>
            <optgroup label="Table maintenance">
                <option value="analyze_tbl">Analyze table</option>
                <option value="check_tbl">Check table</option>
                <option value="checksum_tbl">Checksum table</option>
                <option value="optimize_tbl">Optimize table</option>
                <option value="repair_tbl">Repair table</option>
            </optgroup>
            <optgroup label="Prefix">
                <option value="add_prefix_tbl">Add prefix to table</option>
                <option value="replace_prefix_tbl">Replace table prefix</option>
                <option value="copy_tbl_change_prefix">Copy table with prefix</option>
            </optgroup>
                            <optgroup label="Central columns">
                <option value="sync_unique_columns_central_list">Add columns to central list</option>
                <option value="delete_unique_columns_central_list">Remove columns from central list</option>
                <option value="make_consistent_with_central_list">Make consistent with central list</option>
            </optgroup>
            </select>
    
</div>
</div></form><hr><p class="print_ignore">
    <a href="#" id="printView">
        <span class="nowrap"><img src="mahasiswa_files/dot.gif" title="Print" alt="Print" class="icon ic_b_print">&nbsp;Print</span>
    </a>
    <a href="http://localhost/phpmyadmin/db_datadict.php?db=mahasiswa&amp;amp;goto=db_structure.php" target="print_view">
        <span class="nowrap"><img src="mahasiswa_files/dot.gif" title="Data dictionary" alt="Data dictionary" class="icon ic_b_tblanalyse">&nbsp;Data dictionary</span>
    </a>
</p>
<form id="create_table_form_minimal" method="post" action="tbl_create.php" class="lock-page">
    <fieldset>
        <legend>
        <img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_b_table_add">        Create table        </legend>
        <input type="hidden" name="db" value="mahasiswa"><input type="hidden" name="token" value="P&amp;af_7x$QTS8/}_Y">
        <div class="formelement">
            Name:
            <input type="text" name="table" maxlength="64" size="30" required="required">
        </div>
        <div class="formelement">
            Number of columns:
            <input type="number" min="1" name="num_fields" value="4" required="required">
        </div>
        <div class="clearfloat"></div>
    </fieldset>
    <fieldset class="tblFooters">
        <input type="submit" value="Go">
    </fieldset>
</form>
</div></div><div id="selflink" class="print_ignore"><a href="http://localhost/phpmyadmin/db_structure.php?db=mahasiswa&amp;table=&amp;server=1&amp;target=" title="Open new phpMyAdmin window" target="_blank" rel="noopener noreferrer"><img src="mahasiswa_files/dot.gif" title="Open new phpMyAdmin window" alt="Open new phpMyAdmin window" class="icon ic_window-new"></a></div><div role="log" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div><div role="log" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div><div style="position: fixed; height: auto; width: 700px; top: 17.3748px; left: 329.383px;" tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front ui-dialog-buttons ui-draggable ui-resizable" aria-describedby="pma_navigation_settings" aria-labelledby="ui-id-3"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle"><span id="ui-id-3" class="ui-dialog-title">Page-related settings</span><button type="button" class="ui-button ui-corner-all ui-widget ui-button-icon-only ui-dialog-titlebar-close" title="Close"><span class="ui-button-icon ui-icon ui-icon-closethick"></span><span class="ui-button-icon-space"> </span>Close</button></div><div id="pma_navigation_settings" style="display: block; width: auto; min-height: 138.8px; max-height: 508.05px; height: auto;" class="ui-dialog-content ui-widget-content"><div class="page_settings"><form method="post" action="db_structure.php?db=mahasiswa&amp;table=&amp;server=1&amp;target=" class="config-form disableAjax"><input type="hidden" name="tab_hash" value=""><input type="hidden" name="token" value="P&amp;af_7x$QTS8/}_Y">
<input type="hidden" name="submit_save" value="Navi"><input type="hidden" name="token" value="P&amp;af_7x$QTS8/}_Y"><ul class="tabs responsivetable">

                                    <li class="active">

            <a href="#Navi_panel">
            Navigation panel
            </a>
        </li>
                                <li>

            <a href="#Navi_tree">
            Navigation tree
            </a>
        </li>
                                <li>

            <a href="#Navi_servers">
            Servers
            </a>
        </li>
                                <li>

            <a href="#Navi_databases">
            Databases
            </a>
        </li>
                                <li>

            <a href="#Navi_tables">
            Tables
            </a>
        </li>
            </ul>
<br><div class="tabs_contents"><fieldset class="optbox" id="Navi_panel" style="">
<legend>Navigation panel</legend>
    <p>Customize appearance of the navigation panel.</p>
<table width="100%" cellspacing="0">
<tbody><tr><th><label for="ShowDatabasesNavigationAsTree">Show databases navigation as tree</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDatabasesNavigationAsTree" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>In the navigation panel, replaces the database tree with a selector</small></th><td><span class="checkbox"><input type="checkbox" name="ShowDatabasesNavigationAsTree" id="ShowDatabasesNavigationAsTree" checked="checked"></span><a class="restore-default hide" href="#ShowDatabasesNavigationAsTree" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationLinkWithMainPanel">Link with main panel</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationLinkWithMainPanel" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Link with main panel by highlighting the current database or table.</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationLinkWithMainPanel" id="NavigationLinkWithMainPanel" checked="checked"></span><a class="restore-default hide" href="#NavigationLinkWithMainPanel" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationDisplayLogo">Display logo</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationDisplayLogo" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Show logo in navigation panel.</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationDisplayLogo" id="NavigationDisplayLogo" checked="checked"></span><a class="restore-default hide" href="#NavigationDisplayLogo" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationLogoLink">Logo link URL</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationLogoLink" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>URL where logo in the navigation panel will point to.</small></th><td><input type="text" class="all85" name="NavigationLogoLink" id="NavigationLogoLink" value="index.php"><a class="restore-default hide" href="#NavigationLogoLink" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationLogoLinkWindow">Logo link target</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationLogoLinkWindow" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Open the linked page in the main window (<kbd>main</kbd>) or in a new one (<kbd>new</kbd>).</small></th><td><select class="all85" name="NavigationLogoLinkWindow" id="NavigationLogoLinkWindow"><option value="main" selected="selected">main</option><option value="new">new</option></select><a class="restore-default hide" href="#NavigationLogoLinkWindow" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreePointerEnable">Enable highlighting</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreePointerEnable" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Highlight server under the mouse cursor.</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationTreePointerEnable" id="NavigationTreePointerEnable" checked="checked"></span><a class="restore-default hide" href="#NavigationTreePointerEnable" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="FirstLevelNavigationItems">Maximum items on first level</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_FirstLevelNavigationItems" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>The number of items that can be displayed on each page on the first level of the navigation tree.</small></th><td><input type="number" name="FirstLevelNavigationItems" id="FirstLevelNavigationItems" value="100"><a class="restore-default hide" href="#FirstLevelNavigationItems" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeDisplayItemFilterMinimum">Minimum number of items to display the filter box</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDisplayItemFilterMinimum" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Defines the minimum number of items (tables, views, routines and events) to display a filter box.</small></th><td><input type="number" name="NavigationTreeDisplayItemFilterMinimum" id="NavigationTreeDisplayItemFilterMinimum" value="30"><a class="restore-default hide" href="#NavigationTreeDisplayItemFilterMinimum" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NumRecentTables">Recently used tables</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NumRecentTables" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Maximum number of recently used tables; set 0 to disable.</small></th><td><input type="number" name="NumRecentTables" id="NumRecentTables" value="10"><a class="restore-default hide" href="#NumRecentTables" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NumFavoriteTables">Favorite tables</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NumFavoriteTables" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Maximum number of favorite tables; set 0 to disable.</small></th><td><input type="number" name="NumFavoriteTables" id="NumFavoriteTables" value="10"><a class="restore-default hide" href="#NumFavoriteTables" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationWidth">Navigation panel width</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationWidth" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Set to 0 to collapse navigation panel.</small></th><td><input type="number" name="NavigationWidth" id="NavigationWidth" value="240"><a class="restore-default hide" href="#NavigationWidth" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr></tbody></table>
</fieldset>
<fieldset class="optbox" id="Navi_tree" style="display: none;">
<legend>Navigation tree</legend>
    <p>Customize the navigation tree.</p>
<table width="100%" cellspacing="0">
<tbody><tr><th><label for="MaxNavigationItems">Maximum items in branch</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_MaxNavigationItems" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>The number of items that can be displayed on each page of the navigation tree.</small></th><td><input type="number" name="MaxNavigationItems" id="MaxNavigationItems" value="50"><a class="restore-default hide" href="#MaxNavigationItems" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeEnableGrouping">Group items in the tree</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeEnableGrouping" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Group items in the navigation tree (determined by the separator defined in the Databases and Tables tabs above).</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationTreeEnableGrouping" id="NavigationTreeEnableGrouping" checked="checked"></span><a class="restore-default hide" href="#NavigationTreeEnableGrouping" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeEnableExpansion">Enable navigation tree expansion</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeEnableExpansion" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Whether to offer the possibility of tree expansion in the navigation panel.</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationTreeEnableExpansion" id="NavigationTreeEnableExpansion" checked="checked"></span><a class="restore-default hide" href="#NavigationTreeEnableExpansion" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeShowTables">Show tables in tree</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowTables" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Whether to show tables under database in the navigation tree</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationTreeShowTables" id="NavigationTreeShowTables" checked="checked"></span><a class="restore-default hide" href="#NavigationTreeShowTables" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeShowViews">Show views in tree</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowViews" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Whether to show views under database in the navigation tree</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationTreeShowViews" id="NavigationTreeShowViews" checked="checked"></span><a class="restore-default hide" href="#NavigationTreeShowViews" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeShowFunctions">Show functions in tree</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowFunctions" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Whether to show functions under database in the navigation tree</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationTreeShowFunctions" id="NavigationTreeShowFunctions" checked="checked"></span><a class="restore-default hide" href="#NavigationTreeShowFunctions" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeShowProcedures">Show procedures in tree</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowProcedures" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Whether to show procedures under database in the navigation tree</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationTreeShowProcedures" id="NavigationTreeShowProcedures" checked="checked"></span><a class="restore-default hide" href="#NavigationTreeShowProcedures" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeShowEvents">Show events in tree</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowEvents" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Whether to show events under database in the navigation tree</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationTreeShowEvents" id="NavigationTreeShowEvents" checked="checked"></span><a class="restore-default hide" href="#NavigationTreeShowEvents" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr></tbody></table>
</fieldset>
<fieldset class="optbox" id="Navi_servers" style="display: none;">
<legend>Servers</legend>
    <p>Servers display options.</p>
<table width="100%" cellspacing="0">
<tbody><tr><th><label for="NavigationDisplayServers">Display servers selection</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationDisplayServers" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Display server choice at the top of the navigation panel.</small></th><td><span class="checkbox"><input type="checkbox" name="NavigationDisplayServers" id="NavigationDisplayServers" checked="checked"></span><a class="restore-default hide" href="#NavigationDisplayServers" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="DisplayServersList">Display servers as a list</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_DisplayServersList" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>Show server listing as a list instead of a drop down.</small></th><td><span class="checkbox"><input type="checkbox" name="DisplayServersList" id="DisplayServersList"></span><a class="restore-default hide" href="#DisplayServersList" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr></tbody></table>
</fieldset>
<fieldset class="optbox" id="Navi_databases" style="display: none;">
<legend>Databases</legend>
    <p>Databases display options.</p>
<table width="100%" cellspacing="0">
<tbody><tr><th><label for="NavigationTreeDisplayDbFilterMinimum">Minimum number of databases to display the database filter box</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDisplayDbFilterMinimum" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span></th><td><input type="number" name="NavigationTreeDisplayDbFilterMinimum" id="NavigationTreeDisplayDbFilterMinimum" value="30"><a class="restore-default hide" href="#NavigationTreeDisplayDbFilterMinimum" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeDbSeparator">Database tree separator</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDbSeparator" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>String that separates databases into different tree levels.</small></th><td><input type="text" size="25" name="NavigationTreeDbSeparator" id="NavigationTreeDbSeparator" value="_"><a class="restore-default hide" href="#NavigationTreeDbSeparator" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr></tbody></table>
</fieldset>
<fieldset class="optbox" id="Navi_tables" style="display: none;">
<legend>Tables</legend>
    <p>Tables display options.</p>
<table width="100%" cellspacing="0">
<tbody><tr><th><label for="NavigationTreeDefaultTabTable">Target for quick access icon</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDefaultTabTable" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span></th><td><select class="all85" name="NavigationTreeDefaultTabTable" id="NavigationTreeDefaultTabTable"><option value="structure" selected="selected">Structure</option><option value="sql">SQL</option><option value="search">Search</option><option value="insert">Insert</option><option value="browse">Browse</option></select><a class="restore-default hide" href="#NavigationTreeDefaultTabTable" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeDefaultTabTable2">Target for second quick access icon</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDefaultTabTable2" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span></th><td><select class="all85" name="NavigationTreeDefaultTabTable2" id="NavigationTreeDefaultTabTable2"><option value="" selected="selected"></option><option value="structure">Structure</option><option value="sql">SQL</option><option value="search">Search</option><option value="insert">Insert</option><option value="browse">Browse</option></select><a class="restore-default hide" href="#NavigationTreeDefaultTabTable2" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeTableSeparator">Table tree separator</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeTableSeparator" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span><small>String that separates tables into different tree levels.</small></th><td><input type="text" size="25" name="NavigationTreeTableSeparator" id="NavigationTreeTableSeparator" value="__"><a class="restore-default hide" href="#NavigationTreeTableSeparator" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr><tr><th><label for="NavigationTreeTableLevel">Maximum table tree depth</label><span class="doc"><a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeTableLevel" target="documentation"><img src="mahasiswa_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
</span></th><td><input type="number" name="NavigationTreeTableLevel" id="NavigationTreeTableLevel" value="1"><a class="restore-default hide" href="#NavigationTreeTableLevel" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="mahasiswa_files/dot.gif" title="" alt="" class="icon ic_s_reload" style="display: none;"></a></td></tr></tbody></table>
</fieldset>
</div>
</form>
<script type="text/javascript">
if (typeof configInlineParams === "undefined" || !Array.isArray(configInlineParams)) configInlineParams = [];
configInlineParams.push(function() {
validateField('FirstLevelNavigationItems', 'PMA_validatePositiveNumber', true);
validateField('NumRecentTables', 'PMA_validateNonNegativeNumber', true);
validateField('NumFavoriteTables', 'PMA_validateNonNegativeNumber', true);
validateField('NavigationWidth', 'PMA_validateNonNegativeNumber', true);
validateField('MaxNavigationItems', 'PMA_validatePositiveNumber', true);
validateField('NavigationTreeTableLevel', 'PMA_validatePositiveNumber', true);
$.extend(PMA_messages, {
	'error_nan_p': 'Not a positive number!',
	'error_nan_nneg': 'Not a non-negative number!',
	'error_incorrect_port': 'Not a valid port number!',
	'error_invalid_value': 'Incorrect value!',
	'error_value_lte': 'Value must be equal or lower than %s!'});
$.extend(defaultValues, {
	'ShowDatabasesNavigationAsTree': true,
	'NavigationLinkWithMainPanel': true,
	'NavigationDisplayLogo': true,
	'NavigationLogoLink': 'index.php',
	'NavigationLogoLinkWindow': ['main'],
	'NavigationTreePointerEnable': true,
	'FirstLevelNavigationItems': '100',
	'NavigationTreeDisplayItemFilterMinimum': '30',
	'NumRecentTables': '10',
	'NumFavoriteTables': '10',
	'NavigationWidth': '240',
	'MaxNavigationItems': '50',
	'NavigationTreeEnableGrouping': true,
	'NavigationTreeEnableExpansion': true,
	'NavigationTreeShowTables': true,
	'NavigationTreeShowViews': true,
	'NavigationTreeShowFunctions': true,
	'NavigationTreeShowProcedures': true,
	'NavigationTreeShowEvents': true,
	'NavigationDisplayServers': true,
	'DisplayServersList': false,
	'NavigationTreeDisplayDbFilterMinimum': '30',
	'NavigationTreeDbSeparator': '_',
	'NavigationTreeDefaultTabTable': ['structure'],
	'NavigationTreeDefaultTabTable2': [''],
	'NavigationTreeTableSeparator': '__',
	'NavigationTreeTableLevel': '1'});
});
if (typeof configScriptLoaded !== "undefined" && configInlineParams) loadInlineConfig();
</script>
</div></div><div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix"><div class="ui-dialog-buttonset"><button type="button" class="ui-button ui-corner-all ui-widget">Apply</button><button type="button" class="ui-button ui-corner-all ui-widget">Cancel</button></div></div><div class="ui-resizable-handle ui-resizable-n" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-sw" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-ne" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-nw" style="z-index: 90;"></div></div><div class="ui-widget-overlay ui-front" style="z-index: 800;"></div></body></html>