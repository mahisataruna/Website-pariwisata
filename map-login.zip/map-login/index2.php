<?php
include 'config';

//mengaktifkan session
session_start();

//cek apakah user sudah login
if ($_SESSION['status'] !="login"){
    header("location:..admin/index2.php");
}

//menampilkan timeline anggota
echo "Hai, selamat datang". $_SESSION['username'];

?>
<br/>
<br/>
<a href="logout.php">LOGOUT</a>


